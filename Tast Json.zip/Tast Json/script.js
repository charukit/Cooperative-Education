fetch('5.json')
.then(response => response.json())
.then(data => appendData(data))
.catch(err => { console.log('error: ' + err)})

function appendData(data) {
    var mainContainer = document.getElementById("myData");
    for (var i = 0; i < data.length; i++) {
        var div =document.createElement("div");
        div.innerHTML = `ID: ${data[i].id} 
        Name: ${data[i].name} 
        Author: ${data[i].author} 
        Created_at: ${data[i].created_at} 
        Updated_at: ${data[i].updated_at}`;
        mainContainer.appendChild(div);
    }
}
