const fs = require('fs');

// fs.readFile('./new1.json', 'utf-8', (err, jsonString) => {
//     console.log(jsonString);
// });

function jsonReader(filePath, cb) {
    fs.readFile(filePath, 'utf-8', (err, fileData) => {
        if (err) {
            return cb && cb(err);
        }
        try {
            const object = JSON.parse(fileData);
            return cb && cb(null, object);
        } catch (err) {
            return cb && cb(err);
        }
    });
}

const newObject = [{
    id: 1,
    name: "NodeJS",
    author: "Bell",
    created_at: "2022-11-29T09:27:15.000Z",
    updated_at: "2022-11-29T09:34:32.000Z"
},{
    id: 2,
    name: "JavaScript",
    author: "Charukit Kulchiraphat",
    created_at: "2022-11-29T09:31:05.000Z",
    updated_at: "2022-11-29T09:31:05.000Z"
},{
    id: 3,
    name: "PostMan",
    author: "Ball",
    created_at: "2022",
    updated_at: "2022"
},{
    id: 4,
    name: "Json",
    author: "Mail",
    created_at: "2077",
    updated_at: "2077"
}];

fs.writeFile('./5.json', JSON.stringify(newObject, null, 2), err => {
    if (err) {
        console.log(err);
    } else {
        console.log('File successFully written!');
    }
});

// jsonReader('./new1.json', (err, data) => {
//     if(err){
//         console.log(err);
//     } else {
//         data.id = '1';
//         data.name = 'OMG';
//         data.author = 'GG';
//         fs.writeFile('./new1.json', JSON.stringify(newObject, null, 2), err => {
//             if (err) {
//                 console.log(err);
//             }
//         });
//     }
// });